from dotenv import load_dotenv
import pymongo
import os

load_dotenv()

# notes = { "123": {"title": "yeet", "content": "yah"}}

conn_str = os.getenv('MONGODB_URI')

try:
    client = pymongo.MongoClient(conn_str, serverSelectionTimeoutMS=5000)
    print("Connected to MongoDB")
except Exception:
    print("Unable to connect to MongoDB")

db = client[os.getenv("MONGODB_NAME")]
mongo_collection = db["notes"]

def lambda_handler(event, context):
    # TODO implement
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }